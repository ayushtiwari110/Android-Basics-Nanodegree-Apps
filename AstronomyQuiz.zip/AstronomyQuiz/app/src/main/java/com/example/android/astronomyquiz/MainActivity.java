package com.example.android.astronomyquiz;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    int score = 0;
    int q1 = 0;
    int q2 = 0;
    int q3 = 0;
    int q4 = 0;
    int q5 = 0;
    int q6 = 0;

    //question 1 ans a
    public void question1(View view) {
        RadioButton question1 = findViewById(R.id.ans1a);
        RadioButton q1b = findViewById(R.id.ans1b);
        RadioButton q1c = findViewById(R.id.ans1c);
        RadioButton q1d = findViewById(R.id.ans1d);
        ImageView solutionImage = findViewById(R.id.q1_soln);
        //set correct option as green and image as right
        if (question1.isChecked() || q1b.isChecked() || q1c.isChecked() || q1d.isChecked()) {
            question1.setTextColor(getResources().getColor(R.color.green));
            if (question1.isChecked()) {
                q1 = 1;
                solutionImage.setImageDrawable(getResources().getDrawable(R.drawable.right));
            } else {
                q1 = 0;
                solutionImage.setImageDrawable(getResources().getDrawable(R.drawable.wrong));
            }
            //set other options as red
            q1b.setTextColor(getResources().getColor(R.color.red));
            q1c.setTextColor(getResources().getColor(R.color.red));
            q1d.setTextColor(getResources().getColor(R.color.red));
        } else {
            Toast toast = Toast.makeText(this, "Please select any one option", Toast.LENGTH_SHORT);
            toast.show();
        }
    }

    //question 2 ans d
    public void question2(View view) {
        RadioButton question2 = findViewById(R.id.ans2d);
        RadioButton q2b = findViewById(R.id.ans2b);
        RadioButton q2c = findViewById(R.id.ans2c);
        RadioButton q2a = findViewById(R.id.ans2a);
        ImageView solutionImage = findViewById(R.id.q2_soln);
        //set correct option as green and image as right
        if (question2.isChecked() || q2b.isChecked() || q2c.isChecked() || q2a.isChecked()) {
            question2.setTextColor(getResources().getColor(R.color.green));
            if (question2.isChecked()) {
                q2 = 1;
                solutionImage.setImageDrawable(getResources().getDrawable(R.drawable.right));
            } else {
                q2 = 0;
                solutionImage.setImageDrawable(getResources().getDrawable(R.drawable.wrong));
            }
            //set other options as red
            q2b.setTextColor(getResources().getColor(R.color.red));
            q2c.setTextColor(getResources().getColor(R.color.red));
            q2a.setTextColor(getResources().getColor(R.color.red));
        } else {
            Toast toast = Toast.makeText(this, "Please select any one option", Toast.LENGTH_SHORT);
            toast.show();
        }
    }

    //question 3 ans c
    public void question3(View view) {
        RadioButton question3 = findViewById(R.id.ans3c);
        RadioButton q3b = findViewById(R.id.ans3b);
        RadioButton q3a = findViewById(R.id.ans3a);
        RadioButton q3d = findViewById(R.id.ans3d);
        ImageView solutionImage = findViewById(R.id.q3_soln);
        //set correct option as green and image as right
        if (question3.isChecked() || q3b.isChecked() || q3a.isChecked() || q3d.isChecked()) {
            question3.setTextColor(getResources().getColor(R.color.green));
            if (question3.isChecked()) {
                q3 = 1;
                solutionImage.setImageDrawable(getResources().getDrawable(R.drawable.right));
            } else {
                q3 = 0;
                solutionImage.setImageDrawable(getResources().getDrawable(R.drawable.wrong));
            }
            //set other options as red
            q3b.setTextColor(getResources().getColor(R.color.red));
            q3a.setTextColor(getResources().getColor(R.color.red));
            q3d.setTextColor(getResources().getColor(R.color.red));
        } else {
            Toast toast = Toast.makeText(this, "Please select any one option", Toast.LENGTH_SHORT);
            toast.show();
        }
    }

    //question 4 ans b
    public void question4(View view) {
        RadioButton question4 = findViewById(R.id.ans4b);
        RadioButton q4a = findViewById(R.id.ans4a);
        RadioButton q4c = findViewById(R.id.ans4c);
        RadioButton q4d = findViewById(R.id.ans4d);
        ImageView solutionImage = findViewById(R.id.q4_soln);
        //set correct option as green and image as right
        if (question4.isChecked() || q4a.isChecked() || q4c.isChecked() || q4d.isChecked()) {
            question4.setTextColor(getResources().getColor(R.color.green));
            if (question4.isChecked()) {
                q4 = 1;
                solutionImage.setImageDrawable(getResources().getDrawable(R.drawable.right));
            } else {
                q4 = 0;
                solutionImage.setImageDrawable(getResources().getDrawable(R.drawable.wrong));
            }
            //set other options as red
            q4a.setTextColor(getResources().getColor(R.color.red));
            q4c.setTextColor(getResources().getColor(R.color.red));
            q4d.setTextColor(getResources().getColor(R.color.red));
        } else {
            Toast toast = Toast.makeText(this, "Please select any one option", Toast.LENGTH_SHORT);
            toast.show();
        }
    }

    //question 5
    public void question5(View view) {
        EditText ans5 = findViewById(R.id.answer5);
        String answer5 = ans5.getText().toString();
        ImageView solutionImage = findViewById(R.id.q5_soln);
        if (answer5.matches("")) {
            Toast.makeText(this, "Please input your answer", Toast.LENGTH_SHORT).show();
        } else {
            if (answer5.equalsIgnoreCase("Milky Way")) {
                q5 = 1;
                solutionImage.setImageDrawable(getResources().getDrawable(R.drawable.right));
            } else {
                q5 = 0;
                solutionImage.setImageDrawable(getResources().getDrawable(R.drawable.wrong));
            }
        }
    }

    //question 6 ans b,d
    public void question6(View view) {
        CheckBox ans6a = findViewById(R.id.ans6a);
        CheckBox ans6b = findViewById(R.id.ans6b);
        CheckBox ans6c = findViewById(R.id.ans6c);
        CheckBox ans6d = findViewById(R.id.ans6d);
        ImageView solutionImage = findViewById(R.id.q6_soln);
        Boolean wrong = ans6a.isChecked() || ans6c.isChecked();
        //set correct option as green and image as right
        if (ans6a.isChecked() || ans6b.isChecked() || ans6c.isChecked() || ans6d.isChecked()) {
            ans6b.setTextColor(getResources().getColor(R.color.green));
            ans6d.setTextColor(getResources().getColor(R.color.green));
            if (wrong) {
                q6 = 0;
                solutionImage.setImageDrawable(getResources().getDrawable(R.drawable.wrong));
            } else {
                if (ans6b.isChecked() && ans6d.isChecked()) {
                    q6 = 1;
                    solutionImage.setImageDrawable(getResources().getDrawable(R.drawable.right));
                } else {
                    solutionImage.setImageDrawable(getResources().getDrawable(R.drawable.partial));
                }
            }
            //set other options as red
            ans6a.setTextColor(getResources().getColor(R.color.red));
            ans6c.setTextColor(getResources().getColor(R.color.red));
        } else {
            Toast toast = Toast.makeText(this, "Please select any one or more options", Toast.LENGTH_SHORT);
            toast.show();
        }
    }

    //submit
    public void submit(View view) {
        TextView submit = findViewById(R.id.submit);
        score = q1 + q2 + q3 + q4 + q5 + q6;
        submit.setText("Score: " + score);
        Toast.makeText(this, "Your score is: " + score, Toast.LENGTH_SHORT).show();
    }
}