package com.example.android.newsapplication_at;

import android.location.Location;

public class News {
    //news components
    private String mTitle;
    private String mSection;
    private String mAuthor;
    private String mDate;

    private String mUrl; //for Intent
    public News(String Title, String Section, String Author, String Date,String Url){
        mTitle = Title;
        mSection = Section;
        mAuthor = Author;
        mDate = Date;
        mUrl = Url;
    }
    public String getTitle(){
        return mTitle;
    }
    public String getSection(){
        return mSection;
    }
    public String getAuthor(){
        return mAuthor;
    }
    public String getDate(){
        return mDate;
    }
    public String getUrl(){
        return mUrl;
    }
}
