package com.example.android.newsapplication_at;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;

public class NewsAdapter extends ArrayAdapter<News> {
    public NewsAdapter(Activity context, ArrayList<News> newses) {
        // Here, we initialize the ArrayAdapter's internal storage for the context and the list.
        // the second argument is used when the ArrayAdapter is populating a single TextView.
        // Because this is a custom adapter for four TextViews, the adapter is not
        // going to use this second argument, so it can be any value. Here, we used 0.
        super(context, 0, newses);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listItemView = convertView;
        if(listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.list_item, parent, false);
        }
        //setting adapter for news components.
        News currentNews = getItem(position);
        TextView section = listItemView.findViewById(R.id.news_section);
        section.setText(currentNews.getSection());
        TextView title = listItemView.findViewById(R.id.news_title);
        title.setText(currentNews.getTitle());
        TextView author = listItemView.findViewById(R.id.news_author);
        author.setText(currentNews.getAuthor());
        //NOTE THAT THE DATE RECEIVED BY JSON PARSING CONTAINS SOME WEIRD LETTERS 'T' AND 'Z'
        //AND DATE AND TIME ARE MERGED TOGETHER.
        // SO SEPARATING THE DATEA AND TIME , AND REMOVING THOSE WEIRD LETTERS
        String newsDate_Time = currentNews.getDate();
        String[] parts = newsDate_Time.split("T");
        String date = parts[0];
        String time_with_letterZ = parts[1];
        String[] parts2 = time_with_letterZ.split("Z");
        String time = parts2[0];
        TextView Date = listItemView.findViewById(R.id.news_date);
        Date.setText(date);
        TextView Time = listItemView.findViewById(R.id.news_time);
        Time.setText(time);

        return listItemView;
    }
}
