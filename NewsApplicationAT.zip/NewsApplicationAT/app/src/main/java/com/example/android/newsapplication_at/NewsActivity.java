package com.example.android.newsapplication_at;

import androidx.appcompat.app.AppCompatActivity;
import android.app.LoaderManager;
import android.content.Context;
import android.content.Intent;
import android.content.Loader;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class NewsActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<List<News>>  {

    /**
     * DEFINING GLOBAL VARIABLES
     **/
    private TextView mEmptyStateTextView;
    public static final String LOG_TAG = NewsActivity.class.getName(); //FOR LOGS
    private static final int NEWS_LOADER_ID = 1; //FOR IDENTIFYING EARTHQUAKE LOADER
    private static final String GUARDIAN_REQUEST_URL = "https://content.guardianapis.com/search"; //URL WHICH WILL BE QUERIED.
    private NewsAdapter mAdapter; //adapter to set on screen

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.news_activity);

        //SETTING ADAPTER ON LISTVIEW
        ListView NewsListView = (ListView) findViewById(R.id.list);
        mAdapter = new NewsAdapter(this,new ArrayList<News>());
        NewsListView.setAdapter(mAdapter);

        /**
         * SETTING INTENTS TO WEB BROWSER FOR EACH LIST ITEM
         **/
        NewsListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                News currentNews = mAdapter.getItem(position);
                Uri newsUri = Uri.parse(currentNews.getUrl());
                Intent newsIntent = new Intent(Intent.ACTION_VIEW,newsUri);
                startActivity(newsIntent);
            }
        });

        /**
         * SETTING EMPTY VIEW WHICH IS CURRENTLY INVISIBLE
         **/
        mEmptyStateTextView = (TextView) findViewById(R.id.empty_view);
        NewsListView.setEmptyView(mEmptyStateTextView);

        /**
         * SETTING TEXT ON EMPTY VIEW AS NO INTERNET CONNECTION IN SUITABLE CONDITION
         **/
        // Get a reference to the ConnectivityManager to check state of network connectivity
        ConnectivityManager connMgr = (ConnectivityManager)
                getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected()) {
            LoaderManager loaderManager = getLoaderManager();
            loaderManager.initLoader(NEWS_LOADER_ID, null, this);
        }
        else {
            // Otherwise, display error
            // First, hide loading indicator so error message will be visible
            View loadingIndicator = findViewById(R.id.loading_indicator);
            loadingIndicator.setVisibility(View.GONE);
            // Update empty state with no connection error message
            mEmptyStateTextView.setText(R.string.no_internet_connection);
            mEmptyStateTextView.setTextColor(getResources().getColor(R.color.white));
        }
    }

    /**
     * IMPLEMENTING LOADER METHODS FOR HTTP REQUESTS
     **/
    @Override
    public Loader<List<News>> onCreateLoader(int i, Bundle bundle) {
        SharedPreferences sharedPrefs = PreferenceManager.getDefaultSharedPreferences(this);

        String topic = sharedPrefs.getString(
                getString(R.string.settings_topic_key), getString(R.string.settings_topic_default));
        Uri baseUri = Uri.parse(GUARDIAN_REQUEST_URL);

        // buildUpon prepares the baseUri that we just parsed so we can add query parameters to it
        Uri.Builder uriBuilder = baseUri.buildUpon();
        // Append query parameter and its value.
        uriBuilder.appendQueryParameter("q",topic);
        uriBuilder.appendQueryParameter("show-tags","contributor");
        uriBuilder.appendQueryParameter("api-key","7d593a2e-3f5b-4903-9640-6cf9334d1639"); //using student api key
        return new NewsLoader(this, uriBuilder.toString());
    }
    @Override
    public void onLoadFinished(Loader<List<News>> loader, List<News> newses) {
        View loadingIndicator = findViewById(R.id.loading_indicator);
        loadingIndicator.setVisibility(View.GONE);
        // Clear the adapter of previous news data
        mAdapter.clear();
        // Set empty state text to display the message written.
        mEmptyStateTextView.setText(R.string.no_news);
        mEmptyStateTextView.setTextColor(getResources().getColor(R.color.white));

        // If there is a valid list, then add to the adapter's
        // data set. This will trigger the ListView to update.
        if (newses != null && !newses.isEmpty()) {
            mAdapter.addAll(newses);
        }
    }
    @Override
    public void onLoaderReset(Loader<List<News>> loader) {
        // Loader reset, so we can clear out our existing data.
        mAdapter.clear();
    }

    /**
     * IMPLEMENTATION OF METHODS OF MENU
     **/
    @Override
    // This method initialize the contents of the Activity's options menu.
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the Options Menu we specified in XML
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            Intent settingsIntent = new Intent(this, SettingsActivity.class);
            startActivity(settingsIntent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}