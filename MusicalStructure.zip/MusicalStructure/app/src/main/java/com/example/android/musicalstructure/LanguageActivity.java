package com.example.android.musicalstructure;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class LanguageActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.music_list);
        /*
         * Defining ArrayList
         */
        ArrayList<music> musics = new ArrayList<music>();
        musics.add(new music("Toofan", "Hindi"));
        musics.add(new music("Treat Me", "English"));
        musics.add(new music("Chauffeur", "Punjabi"));
        musics.add(new music("Kalaavathi", "Telugu"));
        musics.add(new music("Sulthana", "Tamil"));
        musics.add(new music("Mehabooba", "Malayalam"));
        musics.add(new music("Gagan Nee", "Kannada"));
        musics.add(new music("Kelewali", "Marathi"));
        musics.add(new music("Naseeb", "Gujarati"));
        musics.add(new music("Silvatiya", "Bhojpuri"));
        /*
         * Setting MusicAdapter
         */
        MusicAdapter adapter = new MusicAdapter(this, musics);
        ListView listView = (ListView) findViewById(R.id.list);
        listView.setAdapter(adapter);
        /*
         * Setting Intent for the Go To Trending Button
         */
        TextView GoToTrending = findViewById(R.id.trending_button);
        GoToTrending.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent TrendingIntent = new Intent(LanguageActivity.this, TrendingActivity.class);
                startActivity(TrendingIntent);
            }
        });
    }
}