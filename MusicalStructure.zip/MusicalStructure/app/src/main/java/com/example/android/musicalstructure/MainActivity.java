package com.example.android.musicalstructure;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //creating @OnClickListener for Trending button
        TextView trending = findViewById(R.id.trending);
        trending.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent TrendingIntent = new Intent(MainActivity.this, TrendingActivity.class);
                startActivity(TrendingIntent);
            }
        });
        //creating @OnClickListener for Artist button
        TextView artist = findViewById(R.id.artist);
        artist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent ArtistIntent = new Intent(MainActivity.this, ArtistActivity.class);
                startActivity(ArtistIntent);
            }
        });
        //creating @OnClickListener for Language button
        TextView language = findViewById(R.id.language);
        language.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent LanguageIntent = new Intent(MainActivity.this, LanguageActivity.class);
                startActivity(LanguageIntent);
            }
        });
        //creating @OnClickListener for Category button
        TextView category = findViewById(R.id.category);
        category.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent CategoryIntent = new Intent(MainActivity.this, CategoryActivity.class);
                startActivity(CategoryIntent);
            }
        });
        //creating @OnClickListener for Mood button
        TextView mood = findViewById(R.id.mood);
        mood.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent MoodIntent = new Intent(MainActivity.this, MoodActivity.class);
                startActivity(MoodIntent);
            }
        });
    }
}