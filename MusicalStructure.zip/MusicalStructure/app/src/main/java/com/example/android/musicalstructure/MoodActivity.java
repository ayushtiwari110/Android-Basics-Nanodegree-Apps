package com.example.android.musicalstructure;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class MoodActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.music_list);
        /*
         * Defining ArrayList
         */
        ArrayList<music> musics = new ArrayList<music>();
        musics.add(new music("Believer", "Joyful"));
        musics.add(new music("Zara Zara", "Sad"));
        musics.add(new music("Aakhon Se Batana", "Calm"));
        musics.add(new music("Lut Gaye", "Romantic"));
        musics.add(new music("Chaand Baaliyan", "Happy"));
        musics.add(new music("Inteqam", "Anger"));
        musics.add(new music("Shape Of You", "Relaxed"));
        musics.add(new music("The Nights", "Excited"));
        musics.add(new music("My Universe", "Good Vibes"));
        musics.add(new music("Gulabi Aankhen", "Love"));
        /*
         * Setting MusicAdapter
         */
        MusicAdapter adapter = new MusicAdapter(this, musics);
        ListView listView = (ListView) findViewById(R.id.list);
        listView.setAdapter(adapter);
        /*
         * Setting Intent for the Go To Trending Button
         */
        TextView GoToTrending = findViewById(R.id.trending_button);
        GoToTrending.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent TrendingIntent = new Intent(MoodActivity.this, TrendingActivity.class);
                startActivity(TrendingIntent);
            }
        });
    }
}