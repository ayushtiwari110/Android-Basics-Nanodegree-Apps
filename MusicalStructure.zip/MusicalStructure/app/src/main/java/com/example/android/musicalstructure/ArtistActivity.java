package com.example.android.musicalstructure;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class ArtistActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.music_list);
        /*
         * Defining ArrayList
         */
        ArrayList<music> musics = new ArrayList<music>();
        musics.add(new music("Toofan", "Sandesh Naik"));
        musics.add(new music("Dhokha", "Arijit Singh"));
        musics.add(new music("Meri Jaan", "Neeti Mohan"));
        musics.add(new music("Srivalli", "Javed Ali"));
        musics.add(new music("Doobey", "Lothika"));
        musics.add(new music("Meri Tarah", "Jubin Nautiyal"));
        musics.add(new music("Saawariya", "Aastha Gill"));
        musics.add(new music("Dholida", "Arohi"));
        musics.add(new music("Beqaaboo", "Savera"));
        musics.add(new music("Param Sundari", "A.R. Rahman"));
        /*
         * Setting MusicAdapter
         */
        MusicAdapter adapter = new MusicAdapter(this, musics);
        ListView listView = (ListView) findViewById(R.id.list);
        listView.setAdapter(adapter);
        /*
         * Setting Intent for the Go To Trending Button
         */
        TextView GoToTrending = findViewById(R.id.trending_button);
        GoToTrending.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent TrendingIntent = new Intent(ArtistActivity.this, TrendingActivity.class);
                startActivity(TrendingIntent);
            }
        });
    }
}