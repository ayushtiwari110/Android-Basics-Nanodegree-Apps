package com.example.android.musicalstructure;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class CategoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.music_list);
        /*
         * Defining ArrayList
         */
        ArrayList<music> musics = new ArrayList<music>();
        musics.add(new music("Tum Mile", "Romance"));
        musics.add(new music("Mera Mann", "Acoustic"));
        musics.add(new music("Pehli Nazar Me", "Bollywood"));
        musics.add(new music("Let Me Down", "Sleep"));
        musics.add(new music("Teri Jhuki Nazar", "LoFi Hip-Hop"));
        musics.add(new music("Chidiya", "Sad"));
        musics.add(new music("Believer", "Workout"));
        musics.add(new music("Aaj Sajeya", "Wedding"));
        musics.add(new music("Chaand Baaliya", "Chill"));
        musics.add(new music("Dil Meri Na", "Drive"));
        /*
         * Setting MusicAdapter
         */
        MusicAdapter adapter = new MusicAdapter(this, musics);
        ListView listView = (ListView) findViewById(R.id.list);
        listView.setAdapter(adapter);
        /*
         * Setting Intent for the Go To Trending Button
         */
        TextView GoToTrending = findViewById(R.id.trending_button);
        GoToTrending.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent TrendingIntent = new Intent(CategoryActivity.this, TrendingActivity.class);
                startActivity(TrendingIntent);
            }
        });
    }
}