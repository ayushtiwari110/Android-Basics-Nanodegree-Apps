package com.example.android.musicalstructure;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class TrendingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.trending_page_list);
        /*
         * Defining ArrayList
         */
        ArrayList<music> musics = new ArrayList<music>();
        musics.add(new music("psychofreak", "Trending 1"));
        musics.add(new music("Treat Me", "Trending 2"));
        musics.add(new music("Versions of Me", "Trending 3"));
        musics.add(new music("MAISON", "Trending 4"));
        musics.add(new music("That's Hilarious", "Trending 5"));
        musics.add(new music("Seven Bridge Road", "Trending 6"));
        musics.add(new music("We Set The Trends", "Trending 7"));
        musics.add(new music("All The Sudden", "Trending 8"));
        musics.add(new music("Lifetime", "Trending 9"));
        musics.add(new music("First Class", "Trending 10"));
        /*
         * Setting MusicAdapter
         */
        MusicAdapter adapter = new MusicAdapter(this, musics);
        ListView listView = (ListView) findViewById(R.id.list);
        listView.setAdapter(adapter);


    }
}