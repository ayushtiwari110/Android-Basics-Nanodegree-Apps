package com.example.android.musicalstructure;

public class music {
    private String mMusicName;
    /*
     * here mHeading will be second property of the music like artist,language,category,etc...
     */
    private String mHeading;

    public music(String musicName, String Heading) {
        mMusicName = musicName;
        mHeading = Heading;
    }

    public String getMusicName() {
        return mMusicName;
    }

    public String getHeading() {
        return mHeading;
    }
}
