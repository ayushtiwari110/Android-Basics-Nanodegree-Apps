package com.example.android.tourguideapp;

public class Tour {
    private String mTitle;
    private String mDescription;
    private int mImageResourceId = NO_IMAGE_PROVIDED;
    private static final int NO_IMAGE_PROVIDED = -1;
    public Tour(String Title, String Description){
        mTitle = Title;
        mDescription = Description;
    }
    public Tour(String Title, String Description, int imageResourceId){
        mTitle = Title;
        mDescription = Description;
        mImageResourceId = imageResourceId;
    }
    public String getTitle(){ return mTitle;}
    public String getDescription(){ return mDescription;}
    public int getImageResourceId(){
        return mImageResourceId;
    }
    public boolean hasImage() {
        return mImageResourceId != NO_IMAGE_PROVIDED;
    }
}
