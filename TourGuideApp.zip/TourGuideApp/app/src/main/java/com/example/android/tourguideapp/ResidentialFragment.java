package com.example.android.tourguideapp;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;

public class ResidentialFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.tour_list, container, false);

        //data for list
        ArrayList<Tour> hostels = new ArrayList<>();
        hostels.add(new Tour(getString(R.string.rhr_name),getString(R.string.rushikulya),R.drawable.ryshikulya));
        hostels.add(new Tour(getString(R.string.bhr_name),getString(R.string.brahmputra),R.drawable.brahmaputra));
        hostels.add(new Tour(getString(R.string.mhr_name),getString(R.string.mahanadi),R.drawable.mahanadi));
        hostels.add(new Tour(getString(R.string.ghr_name),getString(R.string.ganga),R.drawable.ganga));
        hostels.add(new Tour(getString(R.string.shr_name),getString(R.string.subarnrekha),R.drawable.subarnrekha));

        //setting adapter
        TourAdapter adapter = new TourAdapter(requireActivity(), hostels);
        ListView listView = (ListView) rootView.findViewById(R.id.list);
        listView.setAdapter(adapter);
        return rootView;
    }
}