package com.example.android.tourguideapp;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

public class FragmentPageAdapter extends FragmentPagerAdapter {
    private Context mContext;

    public FragmentPageAdapter(Context context,@NonNull FragmentManager fm) {
        super(fm);
        mContext = context;
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        if (position == 0) {
            return new AcademicFragment();
        }
        else if (position == 1){
            return new ResidentialFragment();
        }
        else if (position == 2) {
            return new SportsFragment();
        }
        else {
            return new FoodFragment();
        }
    }

    @Override
    public int getCount() {
        return 4;
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        if (position == 0) {
            return mContext.getString(R.string.category_academics);
        } else if (position == 1) {
            return mContext.getString(R.string.category_residential);
        } else if (position == 2) {
            return mContext.getString(R.string.category_sports);
        } else {
            return mContext.getString(R.string.category_food);
        }
    }
}
