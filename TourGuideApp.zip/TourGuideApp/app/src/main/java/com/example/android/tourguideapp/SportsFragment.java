package com.example.android.tourguideapp;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;

public class SportsFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.tour_list, container, false);

        //adding data to list
        ArrayList<Tour> sportsBuildings = new ArrayList<>();
        sportsBuildings.add(new Tour(getString(R.string.sac_name),getString(R.string.sac)));
        sportsBuildings.add(new Tour(getString(R.string.cc_name),getString(R.string.cc)));

        //setting adapter
        TourAdapter adapter = new TourAdapter(requireActivity(), sportsBuildings);
        ListView listView = (ListView) rootView.findViewById(R.id.list);
        listView.setAdapter(adapter);
        return rootView;
    }
}