package com.example.android.tourguideapp;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Objects;

public class AcademicFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.tour_list, container, false);

        //data for showing in list
        final ArrayList<Tour> schools = new ArrayList<>();
        schools.add(new Tour(getString(R.string.ses_name),getString(R.string.ses)));
        schools.add(new Tour(getString(R.string.sbs_name),getString(R.string.sbs)));
        schools.add(new Tour(getString(R.string.sms_name),getString(R.string.sms)));
        schools.add(new Tour(getString(R.string.sif_name),getString(R.string.sif)));
        schools.add(new Tour(getString(R.string.smme_name),getString(R.string.smme)));
        schools.add(new Tour(getString(R.string.sos_name),getString(R.string.sos)));
        schools.add(new Tour(getString(R.string.shs_name),getString(R.string.shs)));

        //setting listAdapter
        TourAdapter adapter = new TourAdapter(requireActivity(), schools);
        ListView listView = (ListView) rootView.findViewById(R.id.list);
        listView.setAdapter(adapter);
        return rootView;
    }
}